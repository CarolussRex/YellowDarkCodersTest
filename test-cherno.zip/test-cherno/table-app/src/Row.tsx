import { FC, useState } from "react";
import { IDataProps } from "./Interfaces/interfaces";

const Row: FC<IDataProps> = ({
  name,
  email,
  age,
  id,
  deleteElement,
  editElement,
}) => {
  const [visible, setVissible] = useState(false);
  const [edit, setEdit] = useState(false);

  const [currentData, setCurrentData] = useState({
    currentName: name,
    currentEmail: email,
    currentAge: age,
  });

  const turnToEditMenu = () => {
    if (
      currentData.currentName &&
      currentData.currentEmail &&
      currentData.currentAge
    ) {
      editElement(id, currentData);
    }
  };

  return (
    <tr
      onMouseEnter={() => setVissible(true)}
      onMouseLeave={() => setVissible(false)}
    >
      <th scope="row">{id}</th>
      {!edit ? (
        <>
          <td>{name}</td>
          <td>{email}</td>
          <td>{age}</td>
          {visible && (
            <td className="option-bar">
              <span onClick={() => setEdit(true)} style={{ marginLeft: 14 }}>
                Edit
              </span>
              <span
                onClick={() => deleteElement(id)}
                style={{ marginLeft: 14 }}
              >
                Delete
              </span>
            </td>
          )}
        </>
      ) : (
        <>
          <td>
            <input
              type="text"
              minLength={3}
              onChange={(e) =>
                setCurrentData({ ...currentData, currentName: e.target.value })
              }
              value={currentData.currentName}
              onBlur={turnToEditMenu}
            />
          </td>
          <td>
            <input
              type="text"
              minLength={3}
              onChange={(e) =>
                setCurrentData({ ...currentData, currentEmail: e.target.value })
              }
              value={currentData.currentEmail}
              onBlur={turnToEditMenu}
            />
          </td>
          <td>
            <input
              type="number"
              onChange={(e) =>
                setCurrentData({ ...currentData, currentAge: +e.target.value })
              }
              value={currentData.currentAge}
              onBlur={turnToEditMenu}
            />
          </td>
          <td className="option-bar">
            <span onClick={() => setEdit(false)} style={{ marginLeft: 14 }}>
              Done
            </span>
          </td>
        </>
      )}
    </tr>
  );
};

export default Row;
