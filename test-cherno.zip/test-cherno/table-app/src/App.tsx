import { FC, useState } from "react";
import "./App.css";
import Row from "./Row";
import { IEditData, IOrder, IUserData } from "./Interfaces/interfaces";
import sortData from "./ts/additionalFunctions";

const App: FC = () => {
  const [userData, setUserdata] = useState<IUserData[]>([]);

  const [currentData, setCurrentData] = useState({
    name: "",
    email: "",
    age: "",
  });

  const [order, setOrder] = useState<IOrder>({
    order: false,
    sort: "",
  });

  const submitData = () => {
    if (currentData.name && currentData.email && currentData.age) {
      setUserdata((prev) => [
        ...prev,
        { id: Date.now(), ...currentData, age: +currentData.age },
      ]);
      setCurrentData({
        name: "",
        email: "",
        age: "",
      });
    }
  };

  const deleteElement = (id: number) => {
    setUserdata(userData.filter((data) => data.id !== id && data));
  };

  const editElement = (id: number, editData: IEditData) => {
    setUserdata((prevState) => {
      const newState = prevState.map((obj) => {
        if (obj.id === id) {
          return {
            ...obj,
            age: editData.currentAge,
            email: editData.currentEmail,
            name: editData.currentName,
          };
        }
        return obj;
      });
      return newState;
    });
  };

  return (
    <div className="App">
      <div className="container">
        <table className="table table-dark">
          <thead>
            <tr>
              <th
                scope="col"
                onClick={() => setOrder({ order: !order.order, sort: "id" })}
              >
                ID {order.sort === "id" ? (order.order ? "↓" : "↑") : ""}
              </th>
              <th
                scope="col"
                onClick={() => setOrder({ order: !order.order, sort: "name" })}
              >
                Name {order.sort === "name" ? (order.order ? "↓" : "↑") : ""}
              </th>
              <th
                scope="col"
                onClick={() => setOrder({ order: !order.order, sort: "email" })}
              >
                Email {order.sort === "email" ? (order.order ? "↓" : "↑") : ""}
              </th>
              <th
                scope="col"
                onClick={() => setOrder({ order: !order.order, sort: "age" })}
              >
                Age {order.sort === "age" ? (order.order ? "↓" : "↑") : ""}
              </th>
            </tr>
          </thead>
          <tbody>
            {[...userData]
              .sort((a, b) => sortData(a, b, order))
              .map((data) => {
                return (
                  <Row
                    deleteElement={deleteElement}
                    key={data.id}
                    id={data.id}
                    name={data.name}
                    age={data.age}
                    email={data.email}
                    editElement={editElement}
                  />
                );
              })}
            <tr>
              <th scope="row"></th>
              <td>
                <input
                  type="text"
                  onChange={(e) =>
                    setCurrentData({ ...currentData, name: e.target.value })
                  }
                  value={currentData.name}
                  onBlur={submitData}
                />
              </td>
              <td>
                <input
                  type="email"
                  onChange={(e) =>
                    setCurrentData({ ...currentData, email: e.target.value })
                  }
                  value={currentData.email}
                  onBlur={submitData}
                />
              </td>
              <td>
                <input
                  type="number"
                  onChange={(e) =>
                    setCurrentData({ ...currentData, age: e.target.value })
                  }
                  value={currentData.age}
                  onBlur={submitData}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default App;
