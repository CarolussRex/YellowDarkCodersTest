interface IUserData {
  id: number;
  email: string;
  name: string;
  age: number;
}

interface IDataProps extends IUserData {
  deleteElement: Function;
  editElement: Function;
}

interface IEditData {
  currentName: string;
  currentEmail: string;
  currentAge: number;
}

interface IOrder {
  order: boolean;
  sort: string;
}

export type { IEditData, IDataProps, IUserData, IOrder };
