import { IOrder, IUserData } from "../Interfaces/interfaces";

const sortData = (a: IUserData, b: IUserData, order: IOrder) => {
  switch (order.sort) {
    case "id": {
      if (order.order) {
        return a.id > b.id ? -1 : 1;
      }
      return a.id < b.id ? -1 : 1;
    }

    case "name": {
      if (order.order) {
        return a.name > b.name ? -1 : 1;
      }
      return a.name < b.name ? -1 : 1;
    }

    case "email": {
      if (order.order) {
        return a.email > b.email ? -1 : 1;
      }
      return a.email < b.email ? -1 : 1;
    }

    case "age": {
      if (order.order) {
        return a.age > b.age ? -1 : 1;
      }
      return a.age < b.age ? -1 : 1;
    }
    default:
      return 0;
  }
};

export default sortData;
